package main

import (
	"log"
	"os"
	"path/filepath"

	"github.com/webview/webview_go"
)

func main() {
	home, _ := os.UserHomeDir()

	w := webview.New(false)
	defer w.Destroy()
	w.SetTitle("Notpad")
	w.SetSize(800, 600, webview.HintNone)

	w.Bind("getNotes", func() string {
		data, err := os.ReadFile(savePath)
		if err != nil {
			log.Println("read failed:", err)
			return ""
		}
		return string(data)
	})

	w.Bind("saveNotes", func(content string) {
		err := os.WriteFile(savePath, []byte(content), 0644)
		if err != nil {
			log.Println("save FAILED:", err, "path:", savePath)
		}
	})

	w.Navigate(`data:text/html,
	<html><body style="margin:0">
	<textarea id="t" autofocus style="width:100vw;height:100vh;border:0;padding:12px;box-sizing:border-box;font-family:Consolas,monospace;font-size:14px;outline:none;resize:none" placeholder="Just notes..."></textarea>
	<script>
		const t = document.getElementById('t');
		getNotes().then(txt => t.value = txt);
		t.oninput = () => saveNotes(t.value);
		setInterval(() => saveNotes(t.value), 1000);
	</script>
	</body></html>
	`)
	w.Run()
}
